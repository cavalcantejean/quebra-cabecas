package imagem;

import java.awt.Color;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.border.EmptyBorder;

public class Frame12 extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;
	JPanel contentPane;
	JButton btnRanking, btnNovoJogo;
	JLabel foto;
	ImageIcon imagem, imagem2, imagem3;
	Image img, img2, img3;

	public static void main(String[] args) {
		try {
			new Frame12().setVisible(true);
			;
		} catch (IOException e) {
			System.out.println("Imagem n�o existe");
		}
	}

	public Frame12() throws IOException {
		setUndecorated(true);
		getRootPane().setWindowDecorationStyle(JRootPane.FRAME);
		getRootPane().setBorder(BorderFactory.createLineBorder(Color.black, 3));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setIconImage(Toolkit.getDefaultToolkit().getImage(
				"C:\\Users\\Jean\\workspace\\Imagem\\src\\imagem\\PastaImagens\\02.png"));
		setResizable(false);
		setTitle("Jogo da mem�ria");
		setBounds(50, 50, 547, 547);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		btnRanking = new JButton("Ranking");
		btnRanking.setBounds(313, 349, 89, 39);
		contentPane.add(btnRanking);
		btnRanking.addActionListener(this);

		btnNovoJogo = new JButton("Novo Jogo");
		btnNovoJogo.setBounds(104, 349, 89, 39);
		contentPane.add(btnNovoJogo);
		btnNovoJogo.addActionListener(this);

		imagem = new ImageIcon(Frame12.class.getResource("PastaImagens/02.png"));

		foto = new JLabel("");
		foto.setBounds(0, 0, 547, 547);
		contentPane.add(foto);
		img = imagem.getImage().getScaledInstance(foto.getWidth(),
				foto.getHeight(), Image.SCALE_DEFAULT);
		foto.setIcon(new ImageIcon(img));

		imagem2 = new ImageIcon(Frame12.class.getResource("PastaImagens/iniciar4.png"));
		img2 = imagem2.getImage().getScaledInstance(109,
				btnNovoJogo.getHeight(), Image.SCALE_DEFAULT);
		btnNovoJogo.setIcon(new ImageIcon(img2));

		imagem3 = new ImageIcon(Frame12.class.getResource("PastaImagens/ranking3.png"));
		img3 = imagem3.getImage().getScaledInstance(109,
				btnRanking.getHeight(), Image.SCALE_SMOOTH);

		btnRanking.setIcon(new ImageIcon(img3));
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnRanking) {
			try {
				Frame4 frame6 = new Frame4("12",0,0);
				frame6.setVisible(true);
				dispose();
			} catch (IOException e1) {
				e1.printStackTrace();
			}

		} else {
			if (e.getSource() == btnNovoJogo) {
				try {
					Frame2 frame2 = new Frame2();
					frame2.setVisible(true);
					dispose();
				} catch (IOException e1) {
					e1.printStackTrace();
				}

			}
		}
	}
}

package imagem;

import java.awt.Color;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.IOException;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;

public class Frame2 extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;
	JPanel contentPane;
	JButton btnEducativo, btnDinamico;
	JLabel foto;
	JButton btnVoltar;
	ImageIcon imagem, imagem2, imagem3, imagem4;
	Image img, img2, img3, img4;

	public Frame2() throws IOException {
		setUndecorated(true);
		setResizable(false);
		setIconImage(Toolkit.getDefaultToolkit().getImage(
				"C:\\Users\\Jean\\workspace\\Imagem\\src\\imagem\\PastaImagens\\02.png"));
		getRootPane().setWindowDecorationStyle(JRootPane.FRAME);
		getRootPane().setBorder(BorderFactory.createLineBorder(Color.black, 3));
		setTitle("Modo");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(50, 50, 547, 547);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		btnEducativo = new JButton("Iniciar");
		btnEducativo.addActionListener(this);
		btnEducativo.setBounds(353, 151, 89, 39);
		contentPane.add(btnEducativo);

		imagem2 = new ImageIcon(Frame2.class.getResource("PastaImagens/iniciar4.png"));
		img2 = imagem2.getImage().getScaledInstance(109,
				btnEducativo.getHeight(), Image.SCALE_DEFAULT);
		btnEducativo.setIcon(new ImageIcon(img2));

		imagem = new ImageIcon(
				Frame2.class
						.getResource("PastaImagens/coleta-seletiva-em-casa-dados-e-dicas-gerais-3.jpg"));

		imagem4 = new ImageIcon(Frame2.class.getResource("PastaImagens/voltar.jpg"));

		btnDinamico = new JButton("Iniciar");
		btnDinamico.setBounds(353, 367, 89, 39);
		contentPane.add(btnDinamico);
		btnDinamico.setIcon(new ImageIcon(img2));

		btnVoltar = new JButton("Voltar");
		btnVoltar.setBounds(423, 425, 89, 39);
		btnVoltar.addActionListener(this);
		img4 = imagem4.getImage().getScaledInstance(98, btnVoltar.getHeight(),
				Image.SCALE_DEFAULT);
		btnVoltar.setIcon(new ImageIcon(img4));
		contentPane.add(btnVoltar);

		foto = new JLabel("");
		foto.setBounds(0, 0, 547, 547);
		contentPane.add(foto);
		img = imagem.getImage().getScaledInstance(foto.getWidth(),
				foto.getHeight(), Image.SCALE_DEFAULT);
		foto.setIcon(new ImageIcon(img));
		btnDinamico.addActionListener(this);
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnDinamico) {
			try {
				Frame3 frame31 = new Frame3("dinamico");
				frame31.setVisible(true);
				dispose();
			} catch (IOException e1) {
				e1.printStackTrace();
			}

		} else {
			if (e.getSource() == btnEducativo) {
				try {
					Frame3 frame3 = new Frame3("educativo");
					frame3.setVisible(true);
					dispose();
				} catch (IOException e1) {
					e1.printStackTrace();
				}

			} else {
				if (e.getSource() == btnVoltar) {

					try {
						Frame12 frame12 = new Frame12();
						frame12.setVisible(true);
						dispose();
					} catch (IOException e1) {
						e1.printStackTrace();
					}

				}
			}
		}
	}
}

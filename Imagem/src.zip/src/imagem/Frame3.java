package imagem;

import java.awt.Color;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JRootPane;
import javax.swing.border.EmptyBorder;

public class Frame3 extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;
	JPanel contentPane;
	JLabel foto;
	ImageIcon imagem, imagem2, imagem3;
	Image img, img2, img3;
	JRadioButton rdbtnFacil, rdbtnMdio, rdbtnDificil;
	JButton btnIniciar, btnVoltar;
	ButtonGroup btng;
 String modo;

	public Frame3(String modo) throws IOException {
		setResizable(false);
		setUndecorated(true);
		this.modo=modo;
		setIconImage(Toolkit.getDefaultToolkit().getImage(
				"C:\\Users\\Jean\\workspace\\Imagem\\src\\imagem\\PastaImagens\\02.png"));
		getRootPane().setWindowDecorationStyle(JRootPane.FRAME);
		getRootPane().setBorder(BorderFactory.createLineBorder(Color.black, 3));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setTitle("Dificuldade");
		setBounds(50, 50, 547, 547);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		btng = new ButtonGroup();

		btnVoltar = new JButton("Voltar");
		btnVoltar.setBounds(423, 425, 89, 39);
		btnVoltar.addActionListener(this);
		imagem3 = new ImageIcon(Frame3.class.getResource("PastaImagens/voltar.jpg"));
		img3 = imagem3.getImage().getScaledInstance(98, btnVoltar.getHeight(),
				Image.SCALE_DEFAULT);
		btnVoltar.setIcon(new ImageIcon(img3));
		contentPane.add(btnVoltar);

		rdbtnFacil = new JRadioButton("");
		rdbtnFacil.setBackground(Color.LIGHT_GRAY);
		rdbtnFacil.setBounds(93, 170, 21, 23);
		contentPane.add(rdbtnFacil);

		rdbtnMdio = new JRadioButton("");
		rdbtnMdio.setBackground(Color.LIGHT_GRAY);
		rdbtnMdio.setBounds(93, 248, 21, 23);
		contentPane.add(rdbtnMdio);

		rdbtnDificil = new JRadioButton("");
		rdbtnDificil.setBackground(Color.LIGHT_GRAY);
		rdbtnDificil.setBounds(93, 315, 21, 23);
		contentPane.add(rdbtnDificil);

		btng.add(rdbtnDificil);
		btng.add(rdbtnFacil);
		btng.add(rdbtnMdio);

		btnIniciar = new JButton("Iniciar");
		btnIniciar.setBounds(164, 425, 89, 39);
		contentPane.add(btnIniciar);

		imagem = new ImageIcon(Frame3.class.getResource("PastaImagens/rio-citarum-2.jpg"));
		imagem2 = new ImageIcon(Frame3.class.getResource("PastaImagens/iniciar4.png"));

		foto = new JLabel("");
		foto.setBounds(0, 0, 547, 547);
		contentPane.add(foto);
		img = imagem.getImage().getScaledInstance(foto.getWidth(),
				foto.getHeight(), Image.SCALE_DEFAULT);
		foto.setIcon(new ImageIcon(img));
		img2 = imagem2.getImage().getScaledInstance(100,
				btnIniciar.getHeight(), Image.SCALE_DEFAULT);
		btnIniciar.setIcon(new ImageIcon(img2));
		btnIniciar.addActionListener(this);
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnIniciar) {
			if(rdbtnDificil.isSelected()&&modo=="dinamico"){
				TelaJogo facil_edu = new TelaJogo(2,1);
				facil_edu.setVisible(true);
				facil_edu.prepararJogo();
				facil_edu.prepararImagens();
				dispose();
			}else{
				if(rdbtnMdio.isSelected()&&modo=="dinamico"){
					TelaJogo facil_edu = new TelaJogo(2,1);
					facil_edu.setVisible(true);
					facil_edu.prepararJogo();
					facil_edu.prepararImagens();
					dispose();
				}else{
					if(rdbtnFacil.isSelected()&&modo=="dinamico"){
						TelaJogo facil_edu = new TelaJogo(1,1);
						facil_edu.setVisible(true);
						facil_edu.prepararJogo();
						facil_edu.prepararImagens();
						dispose();
					}else{
						if (rdbtnFacil.isSelected()&&modo=="educativo") {
							TelaJogo2 facil_edu = new TelaJogo2(1,1);
							facil_edu.setVisible(true);
							facil_edu.prepararJogo();
							facil_edu.prepararImagens();
							dispose();
						} else {
							if (rdbtnMdio.isSelected()&&modo=="educativo") {
								TelaJogo2 medio_edu = new TelaJogo2(2,1);
								medio_edu.setVisible(true);
								medio_edu.prepararJogo();
								medio_edu.prepararImagens();
								dispose();
							} else {
								if (rdbtnDificil.isSelected()&&modo=="educativo") {
									TelaJogo2 dificil_edu = new TelaJogo2(3,1);
									dificil_edu.setVisible(true);
									dificil_edu.prepararJogo();
									dificil_edu.prepararImagens();
									dispose();
								} else {
									JOptionPane.showMessageDialog(null,
											"Selecione a dificuldade");
								}
							}
						}
					}
				}
			}
			
			
			
			
			
			
			
			

		} else {
			if (e.getSource() == btnVoltar) {
				try {
					Frame2 frame2 = new Frame2();
					frame2.setVisible(true);
					dispose();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		}
	}
}

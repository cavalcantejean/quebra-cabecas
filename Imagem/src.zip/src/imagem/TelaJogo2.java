package imagem;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

public class TelaJogo2 extends JFrame implements ActionListener {

	/**
	 * 
	 */
	
	private static final long serialVersionUID = 1L;
	private Pontuacao pontuacao = new Pontuacao();
	 private Imagens obj1, obj2;
	 private int nivel, tema, nivelQnt;
	 private String temaImg;
	 private boolean primeiroClique = true;
	 private boolean acertou = true;
	 private Object img1 = new Object();
	 private Object img2 = new Object();
	 ImageIcon imagemPadrao;
	 private JLabel pontos;
	 private JPanel painelCabecalho, painelJogo, painelSub, painelGeral;
	 private ArrayList<Icon> imagensArray;
	 private GridLayout gridCabecalho, gridJogo, gridSub;
	 private ArrayList<Imagens> imagens;
	 private final Container container;
	 private JMenuBar menuBar;
	 private JMenu mnOpes;
	 private JMenuItem mntmNovoJogo;
	 private JMenuItem mntmRanking;
	 private JMenuItem mntmMenu;
	 private JMenuItem mntmVoltar;
	 
	 void prepararJogo() {
		    // nivelQnt recebe o n�mero de cartas do jogo de acordo com n�vel escolhido
		    if(this.nivel == 1) nivelQnt = 12;
		    else if(this.nivel == 2) nivelQnt = 24;
		    else nivelQnt = 36;

		    // temaImg recebe o correspondente ao tema escolhido
		    if(this.tema == 1) { temaImg = "animes"; }
		    else { if(this.tema == 2) { temaImg = "games"; }
		    else { temaImg = "series"; } }
		 }
	 
	 void prepararImagens() {
		    // inicializar vetor
		    imagensArray = new ArrayList<Icon>();
		    int i;
		    for(i=0; i<nivelQnt; i++)
		       // inserir as imagens de acordo com o tema
		       this.imagensArray.add(new ImageIcon(getClass().getResource("PastaImagens/" + temaImg + " (" + (i+1) + ").png")));
		 }
	 
	 public TelaJogo2(int nivel, int tema) {
		 setUndecorated(true);
			getRootPane().setWindowDecorationStyle(JRootPane.FRAME);
			getRootPane().setBorder(BorderFactory.createLineBorder(Color.black, 3));
			setIconImage(Toolkit.getDefaultToolkit().getImage(
					"C:\\Users\\Jean\\workspace\\Imagem\\src\\imagem\\PastaImagens\\02.png"));
			setTitle("Jogo da Mem�ria Educativo");
		 this.nivel = nivel;
		 this.tema = tema;
		 prepararJogo();
		 prepararImagens();
		 new ImageIcon(getClass().getResource("PastaImagens/tema_" + temaImg + ".png"));
		 // gerenciadores de layout
		 gridCabecalho = new GridLayout(1,1,0,0);
		 gridSub = new GridLayout(1,2,0,0);
		 // verificar qual deve ser a disposi��o de bot�es de acordo com o n�vel
		 if(this.nivel == 1) gridJogo = new GridLayout(3,4,0,0);
		 else if(this.nivel == 2) gridJogo = new GridLayout(3,8,0,0);
		 else gridJogo = new GridLayout(4,9,0,0);
		// configurar painelCabecalho
		 painelCabecalho = new JPanel();
		 painelCabecalho.setLayout(gridCabecalho);
		 // configurar painelJogo
		 painelJogo = new JPanel();
		 painelJogo.setLayout(gridJogo);

		 int numObj = 0;
		 imagens = new ArrayList<Imagens>();
		 // preencher todos os bot�es com a imagem padr�o, sua imagem e sua idenfica��o
		 for (Icon imagem : imagensArray) {
		    numObj++;
		    imagens.add(new Imagens(imagemPadrao, imagem, numObj));
		    imagens.get(numObj-1).addActionListener(this);
		 }

		 // embaralhar os bot�es
		 Collections.shuffle(imagens);
		 for (Imagens imagem : imagens)
		    painelJogo.add(imagem);
		 
		// configurar pontos
		 pontos = new JLabel("Pontua��o: " + String.valueOf(pontuacao.getPontos()));
		 
		// configurar painelSub
		 painelSub = new JPanel();
		 painelSub.setLayout(gridSub);
		 painelSub.add(pontos);
		 
		// configurar painelGeral
		 painelGeral = new JPanel();
		 painelGeral.setLayout(new BorderLayout(10,10));
		 painelGeral.add(painelCabecalho, BorderLayout.NORTH);
		 painelGeral.add(painelJogo, BorderLayout.CENTER);
		 painelGeral.add(painelSub, BorderLayout.SOUTH);
		 
		 // configurar container
		 container = getContentPane();
		 container.setLayout(new BorderLayout(5,5));
		 container.add(painelGeral);
		 
		 if(this.nivel == 1) { setSize(600,470); setLocation(50,50);}
		 else { if(this.nivel == 2) { setSize(930,470);setLocation(50,50); }
		 else { setSize(900,600);setLocation(50,50); } }

		 setResizable(false);
		 
		 menuBar = new JMenuBar();
		 setJMenuBar(menuBar);
		 

		 
		 mnOpes = new JMenu("Op\u00E7\u00F5es");
		 menuBar.add(mnOpes);
		 
		 mntmNovoJogo = new JMenuItem("Novo Jogo");
		 mnOpes.add(mntmNovoJogo);
		 mntmNovoJogo.addActionListener(this);
		 
		 mntmRanking = new JMenuItem("Ranking");
		 mnOpes.add(mntmRanking);
		 mntmRanking.addActionListener(this);
		 
		 mntmVoltar = new JMenuItem("Voltar");
		 mnOpes.add(mntmVoltar);
		 mntmVoltar.addActionListener(this);
		 
		 mntmMenu = new JMenuItem("Menu");
		 mnOpes.add(mntmMenu);
		 mntmMenu.addActionListener(this);
		 setVisible(true);			       
	 }

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==mntmMenu){
			try {
				Frame12 frame12 = new Frame12();
				frame12.setVisible(true);
				dispose();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			
		}
		
		if(e.getSource()==mntmVoltar){
			try {
				Frame3 frame3 = new Frame3("educativo");
				frame3.setVisible(true);
				dispose();
			} catch (IOException e1) {
				e1.printStackTrace();
			}	
		}
		
		if(e.getSource()==mntmNovoJogo){
			if(this.nivel==1&&this.tema==1){
				TelaJogo2 tela = new TelaJogo2(1,1);
				tela.setVisible(true);
				dispose();
				}else{
					if(this.nivel==1&&this.tema==2){
						TelaJogo2 tela = new TelaJogo2(1,2);
						tela.setVisible(true);
						dispose();
					}else{
						if(this.nivel==1&&this.tema==3){
							TelaJogo2 tela = new TelaJogo2(1,3);
							tela.setVisible(true);
							dispose();
						}else{
							if(this.nivel==2&&this.tema==1){
								TelaJogo2 tela = new TelaJogo2(2,1);
								tela.setVisible(true);
								dispose();
							}else{
								if(this.nivel==2&&this.tema==2){
									TelaJogo2 tela = new TelaJogo2(2,2);
									tela.setVisible(true);
									dispose();
								}else{
									if(this.nivel==2&&this.tema==3){
										TelaJogo2 tela = new TelaJogo2(2,3);
										tela.setVisible(true);
										dispose();
									}else{
										if(this.nivel==3&&this.tema==1){
											TelaJogo2 tela = new TelaJogo2(3,1);
											tela.setVisible(true);
											dispose();
										}else{
											if(this.nivel==3&&this.tema==2){
												TelaJogo2 tela = new TelaJogo2(3,2);
												tela.setVisible(true);
												dispose();
											}else{
												if(this.nivel==3&&this.tema==3){
													TelaJogo2 tela = new TelaJogo2(3,3);
													tela.setVisible(true);
													dispose();
												}
											}
										}
									}
								}
							}
						}
					}
				}
		}
		
		if(e.getSource()==mntmRanking){
			try {
				Frame4 frame4 = new Frame4("TelaJogo2",this.nivel,this.tema);
				frame4.setVisible(true);
				dispose();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		 
		 else {
			    // testa se � o primeiro clique
			    if(primeiroClique){
			       // testa se o jogador errou na jogada anterior
			       if (!acertou){
			          obj1 = (Imagens) img1;
			          obj2 = (Imagens) img2;
			          obj1.setImagemPadrao();
			          obj2.setImagemPadrao();
			       }
			       img1 = e.getSource();
			       obj1 = (Imagens) img1;
			       obj1.setImagemObjeto();
			       
			       // indica que este foi o primeiro clique
			       primeiroClique = false;
			    }
			    
			    // se n�o for o primeiro clique
			    else{
			       img2 = e.getSource();
			       obj2 = (Imagens) img2;
			       
			       // verifica se jogador clicou no mesmo objeto
			       if (obj1.getID() == obj2.getID()) {
			          acertou = false;
			          JOptionPane.showMessageDialog( null, "CLIQUE EM OUTRA IMAGEM!",
			          "Aten��o", JOptionPane.WARNING_MESSAGE );
			       } else{
			    	   
			           // atualiza imagem
			           obj2.setImagemObjeto();
			           
			           // compara com o primeiro
			           if ( (obj1.getID()%2 == 0) && (obj1.getID()-1 == obj2.getID()) || (obj1.getID()%2 != 0) && (obj1.getID()+1 == obj2.getID()) ) {
			        	   
			        	     acertou = true;
			                 pontuacao.setAcertos();
			                 pontuacao.ganharPontos();
			                 pontos.setText("Pontua��o: " + String.valueOf(pontuacao.getPontos()));
			                 
			              // Desabilita os bot�es
			                 obj1.setEnabled( false );
			                 obj2.setEnabled( false );
			                 
			                 // se foi o �ltimo par encontrado, encerra jogo
			                 if (pontuacao.getAcertos() == ((nivelQnt)/2) ){
			                   JOptionPane.showMessageDialog( null, "PARAB�NS!!!" +
			                   "\nVoc� conseguiu " + pontuacao.getPontos() + " pontos",
			                   "Fim", JOptionPane.INFORMATION_MESSAGE );
			                   setVisible( false );
			                   System.gc();
			                 }
			             } else{
			                acertou = false;
			                pontuacao.perderPontos();
			                pontos.setText("Pontua��o: " + String.valueOf(pontuacao.getPontos()));
			             }
			             pontuacao.setTentativas();
			             // indica que este foi o segundo clique
			             primeiroClique = true;
			          }
			         }
			       }
		
	}
}

package imagem;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class FimDeJogo extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 */
	public FimDeJogo() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("Sair");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnNewButton.setBounds(289, 147, 89, 23);
		contentPane.add(btnNewButton);
		
		JLabel lblFimDeJogo = new JLabel("Fim de Jogo!");
		lblFimDeJogo.setFont(new Font("Tahoma", Font.PLAIN, 22));
		lblFimDeJogo.setBounds(154, 26, 137, 23);
		contentPane.add(lblFimDeJogo);
		
		JLabel lblVocePerdeu = new JLabel("Voce perdeu!!!");
		lblVocePerdeu.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblVocePerdeu.setBounds(164, 37, 103, 50);
		contentPane.add(lblVocePerdeu);
		
		JLabel lblSuaPontuao = new JLabel("Sua pontua\u00E7\u00E3o \u00E9:");
		lblSuaPontuao.setBounds(174, 99, 92, 14);
		contentPane.add(lblSuaPontuao);
		
		JButton btnJogarNovamente = new JButton("Jogar Novamente");
		btnJogarNovamente.setBounds(146, 202, 127, 23);
		contentPane.add(btnJogarNovamente);
		
		JButton btnMenu = new JButton("Menu");
		btnMenu.setBounds(168, 147, 89, 23);
		contentPane.add(btnMenu);
		
		JButton btnRanking = new JButton("Ranking");
		btnRanking.setBounds(25, 147, 89, 23);
		contentPane.add(btnRanking);
	}
}

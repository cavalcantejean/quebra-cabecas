package imagem;

import java.awt.Color;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.border.EmptyBorder;

public class Frame4 extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;
	ImageIcon image, foto2, image2;
	Image img, img2;
	JPanel contentPane;
	JLabel foto, Label5, Label3_1, Label1_1, Label2_1, Label4_1, Label5_1,
			Label3_2, Label1_2, Label2_2, Label4_2, Label5_2;
	JLabel lblNewLabel;
	JButton btnVoltar;
	String janela;
	int nivel;
	int tema;

	public Frame4(String janela,int nivel,int tema) throws IOException {
		setUndecorated(true);
		this.janela= janela;
		this.nivel=nivel;
		this.tema=tema;
		setIconImage(Toolkit.getDefaultToolkit().getImage(
				"C:\\Users\\Jean\\workspace\\Imagem\\src\\imagem\\PastaImagens\\02.png"));
		getRootPane().setWindowDecorationStyle(JRootPane.FRAME);
		setTitle("Ranking");
		setResizable(false);
		getRootPane().setBorder(BorderFactory.createLineBorder(Color.black, 3));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(50, 50, 547, 547);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		btnVoltar = new JButton("Voltar");
		btnVoltar.addActionListener(this);
		btnVoltar.setBounds(423, 425, 89, 39);
		image2 = new ImageIcon(Frame4.class.getResource("PastaImagens/voltar.jpg"));
		img2 = image2.getImage().getScaledInstance(98, btnVoltar.getHeight(),
				Image.SCALE_DEFAULT);
		btnVoltar.setIcon(new ImageIcon(img2));
		contentPane.add(btnVoltar);

		Label1_1 = new JLabel("New label");
		Label1_1.setForeground(Color.WHITE);
		Label1_1.setBounds(222, 222, 46, 14);
		contentPane.add(Label1_1);

		Label2_1 = new JLabel("New label");
		Label2_1.setForeground(Color.WHITE);
		Label2_1.setBounds(222, 259, 46, 14);
		contentPane.add(Label2_1);

		Label3_1 = new JLabel("New label");
		Label3_1.setForeground(Color.WHITE);
		Label3_1.setBounds(222, 296, 46, 14);
		contentPane.add(Label3_1);

		Label4_1 = new JLabel("New label");
		Label4_1.setForeground(Color.WHITE);
		Label4_1.setBounds(222, 335, 46, 14);
		contentPane.add(Label4_1);

		Label5_1 = new JLabel("New label");
		Label5_1.setForeground(Color.WHITE);
		Label5_1.setBounds(222, 376, 46, 14);
		contentPane.add(Label5_1);

		Label1_2 = new JLabel("New label");
		Label1_2.setForeground(Color.WHITE);
		Label1_2.setBounds(361, 222, 46, 14);
		contentPane.add(Label1_2);

		Label2_2 = new JLabel("New label");
		Label2_2.setForeground(Color.WHITE);
		Label2_2.setBounds(361, 259, 46, 14);
		contentPane.add(Label2_2);

		Label3_2 = new JLabel("New label");
		Label3_2.setForeground(Color.WHITE);
		Label3_2.setBounds(361, 296, 46, 14);
		contentPane.add(Label3_2);

		Label4_2 = new JLabel("New label");
		Label4_2.setForeground(Color.WHITE);
		Label4_2.setBounds(361, 335, 46, 14);
		contentPane.add(Label4_2);

		Label5_2 = new JLabel("New label");
		Label5_2.setForeground(Color.WHITE);
		Label5_2.setBounds(361, 376, 46, 14);
		contentPane.add(Label5_2);

		lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(0, 0, 547, 547);
		contentPane.add(lblNewLabel);

		foto2 = new ImageIcon(
				Frame4.class.getResource("PastaImagens/natureza-bela-1024x768-3.jpg"));

		img = foto2.getImage().getScaledInstance(lblNewLabel.getWidth(),
				lblNewLabel.getHeight(), Image.SCALE_DEFAULT);
		lblNewLabel.setIcon(new ImageIcon(img));
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnVoltar) {			
					if(janela=="12"){
						try {
							Frame12 frame12 = new Frame12();
							frame12.setVisible(true);
							dispose();
						} catch (IOException e1) {
							e1.printStackTrace();
						}
					}else{
						if(janela=="TelaJogo"&&nivel==1&&tema==1){
							TelaJogo tela = new TelaJogo(1,1);
							tela.setVisible(true);
							dispose();
						}else{
							if(janela=="TelaJogo"&&nivel==1&&tema==2){
								TelaJogo tela = new TelaJogo(1,2);
								tela.setVisible(true);
								dispose();
							}else{
								if(janela=="TelaJogo"&&nivel==1&&tema==3){
									TelaJogo tela = new TelaJogo(1,3);
									tela.setVisible(true);
									dispose();
								}else{
									if(janela=="TelaJogo"&&nivel==2&&tema==1){
										TelaJogo tela = new TelaJogo(2,1);
										tela.setVisible(true);
										dispose();
									}else{
										if(janela=="TelaJogo"&&nivel==2&&tema==2){
											TelaJogo tela = new TelaJogo(2,2);
											tela.setVisible(true);
											dispose();
										}else{
											if(janela=="TelaJogo"&&nivel==2&&tema==3){
												TelaJogo tela = new TelaJogo(2,3);
												tela.setVisible(true);
												dispose();
											}else{
												if(janela=="TelaJogo"&&nivel==3&&tema==1){
													TelaJogo tela = new TelaJogo(3,1);
													tela.setVisible(true);
													dispose();
												}else{
													if(janela=="TelaJogo"&&nivel==3&&tema==2){
														TelaJogo tela = new TelaJogo(3,2);
														tela.setVisible(true);
														dispose();
													}else{
														if(janela=="TelaJogo"&&nivel==3&&tema==3){
															TelaJogo tela = new TelaJogo(3,3);
															tela.setVisible(true);
															dispose();
														}else{
															if(janela=="TelaJogo2"&&nivel==1&&tema==1){
																TelaJogo2 tela = new TelaJogo2(1,1);
																tela.setVisible(true);
																dispose();
															}else{
																if(janela=="TelaJogo2"&&nivel==1&&tema==2){
																	TelaJogo2 tela = new TelaJogo2(1,2);
																	tela.setVisible(true);
																	dispose();
																}else{
																	if(janela=="TelaJogo2"&&nivel==1&&tema==3){
																		TelaJogo2 tela = new TelaJogo2(1,3);
																		tela.setVisible(true);
																		dispose();
																	}else{
																		if(janela=="TelaJogo2"&&nivel==2&&tema==1){
																			TelaJogo2 tela = new TelaJogo2(2,1);
																			tela.setVisible(true);
																			dispose();
																		}else{
																			if(janela=="TelaJogo2"&&nivel==2&&tema==2){
																				TelaJogo2 tela = new TelaJogo2(2,2);
																				tela.setVisible(true);
																				dispose();
																			}else{
																				if(janela=="TelaJogo2"&&nivel==2&&tema==3){
																					TelaJogo2 tela = new TelaJogo2(2,3);
																					tela.setVisible(true);
																					dispose();
																				}else{
																					if(janela=="TelaJogo2"&&nivel==3&&tema==1){
																						TelaJogo2 tela = new TelaJogo2(3,1);
																						tela.setVisible(true);
																						dispose();
																					}else{
																						if(janela=="TelaJogo2"&&nivel==3&&tema==2){
																							TelaJogo2 tela = new TelaJogo2(3,2);
																							tela.setVisible(true);
																							dispose();
																						}else{
																							if(janela=="TelaJogo2"&&nivel==3&&tema==3){
																								TelaJogo2 tela = new TelaJogo2(3,3);
																								tela.setVisible(true);
																								dispose();
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		
	}

